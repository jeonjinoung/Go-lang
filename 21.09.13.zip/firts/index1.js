function let(){
    let = 3;
}
console.log(let);